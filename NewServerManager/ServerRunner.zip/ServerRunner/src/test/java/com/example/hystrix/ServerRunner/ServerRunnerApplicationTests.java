package com.example.hystrix.ServerRunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
